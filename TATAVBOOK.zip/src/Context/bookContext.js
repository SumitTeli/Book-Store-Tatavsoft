import { createContext } from 'react'

const bookContext = createContext();

export default bookContext
